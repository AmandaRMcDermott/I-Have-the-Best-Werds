#' @title uniquer_row
#'
#' @description Takes a data frame and returns count of how many unique rows there
#' Details
#'
#' @author Amanda McDermott
#'
#' @param df A data frame
#'
#' @return A numeric value of how many unique rows counts were in the data frame
#'
#'
#' @export

uniquer_row <- function(df){
  nrow(unique(df))
}
