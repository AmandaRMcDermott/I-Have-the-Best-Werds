#' @title uniquer_col
#'
#' @description Takes a data frame and returns unique column values
#'
#' Details
#'
#' @author Amanda McDermott
#'
#' @param df A data frame
#'
#' @return A numeric value of how many unique counts in each column there were
#'
#' @export

uniquer_col <- function(df){
  sapply(df, function(x) length(unique(x)))
}

