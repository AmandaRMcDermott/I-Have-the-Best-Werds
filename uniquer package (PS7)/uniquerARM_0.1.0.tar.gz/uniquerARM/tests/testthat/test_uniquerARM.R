library(uniquerARM)

y <-  data.frame(
  "col1" = c(1, 2, 3, 4, 5),
  "col2" = c(6, 7, 8, 9, 10),
  "col3" = c(11, 12, 13, 14, 15)
)

test_that("gets correct unique rows", {
  expect_equal(uniquer_row(y), 5)
})
