library(testthat)
library(uniquerARM)

test_check("uniquerARM")
